<!DOCTYPE html>
<html>
    <head>
        <title>Página de livros</title>
        <meta charset="UTF-8">
    </head>
    <body>
        <form method="POST" action="clientes.php">
            <p>
                <label for="txtnome">Nome</label>
                <input type="text" id="txtnome" name="nome"/>
            </p>
            <p>
                <label for="txtautor">Autor</label>
                <input type="text" id="txtautor" name="autor"/>
            </p>
            <p>
                <label for="txtidioma">Idioma</label>
                <select name="idioma" id="txtidioma">
                    <option>Português</option>
                    <option>Inglês</option>
                </select>
            </p>
            <p>
                <input type="submit" name="Enviar"/>
            </p>
        </form>
    </body>
</html>