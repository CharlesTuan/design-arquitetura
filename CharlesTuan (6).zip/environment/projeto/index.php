<!DOCTYPE html>
<html>
    <head>
    <?php
        include 'teste.php';
        include 'teste2.php';
        include 'teste3.php';
        include 'teste4.php';
        include 'teste5.php';
        include 'teste6.php';
    ?>    
    </head>
    <body>
        <a href="teste6.php?nome=zezinho&sobrenome=silva"> LINK </a>
    </body>
<html>