<!DOCTYPE html>
<html>
    <head>
        
        
    </head>
    <body>
        <?php
            function imprime($nome = ""){
                echo "eu não acredito: " . $nome;
            }
            imprime("zezinho");
        ?>
    </body>
<html>