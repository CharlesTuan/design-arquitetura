<!DOCTYPE html>
<html>
    <head>
        
        
    </head>
    <body>
        <?php
            $data = date("d.m.y H:i:s", time());
            echo "<p align='center'> Hoje é: $data</p>";
        ?>
    </body>
<html>