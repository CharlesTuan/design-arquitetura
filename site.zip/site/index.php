<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>charles tuan -trabalhaço</title>

  <!-- Bootstrap core CSS -->
  <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="css/heroic-features.css" rel="stylesheet">

</head>

<body>
<?php
  include'menu.php';
?>
  <!-- Page Content -->
  <div class="container">

    <!-- Jumbotron Header -->
    <header class="jumbotron my-4">
      <h1 class="display-3">Salve Waltinho</h1>
        <p class="lead">Só clicar ali em cima no meu para executar login que o resto ta facin, ou clica aqui em baixo mesmo.</p>
      <a href="login.php" class="btn btn-primary btn-lg">Aqui tambem</a>
    </header>

    <!-- Page Features -->
    <div class="row text-center">

      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">aqui não faz nada </h4>
            <p class="card-text">faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada .</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">será que não faz?</a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
          <h4 class="card-title">aqui não faz nada </h4>
            <p class="card-text">faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada .</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">será que não faz?</a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">aqui não faz nada </h4>
            <p class="card-text">faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada .</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">será que não faz?</a>
          </div>
        </div>
      </div>

      <div class="col-lg-3 col-md-6 mb-4">
        <div class="card h-100">
          <img class="card-img-top" src="http://placehold.it/500x325" alt="">
          <div class="card-body">
            <h4 class="card-title">aqui não faz nada </h4>
            <p class="card-text">faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada faz nada .</p>
          </div>
          <div class="card-footer">
            <a href="#" class="btn btn-primary">será que não faz?</a>
          </div>
        </div>
      </div>

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; O brabo 2077</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
