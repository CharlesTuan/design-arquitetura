<?php
   $con=mysqli_connect("localhost","bob","bob","univille") or die (mysql_error('Erro na conexão'));   
?>